"""Recovered-source compatibility witnesses, separate from frozen baseline."""
import json
import math
import importlib
from .registry import ROOT
from .replay import load_reference, reference_wound, serialize
from .check_legacy import FACTORIES, INPUTS


def check_recovered(check):
    rows=json.loads((ROOT/'evidence/legacy_registry.json').read_text());results=[]
    for row in rows:
        sid=row['substrate_id'];payload=row['embedded_payloads']
        args={k:payload[v] for k,v in FACTORIES.get(sid,{}).items()}
        try:
            profile=load_reference(sid,factory_arguments=args or None,transfer_version='recovered')
            result=reference_wound(sid,profile,INPUTS.get(sid,{}))
            results.append(dict(id=sid,status='EXECUTED',result=result,
                                config=serialize(getattr(profile,'config',profile))))
            check('G-RECOVERED-070',sid,'recovered reference executed; unreported fields null; not physical calibration')
        except Exception as exc:
            results.append(dict(id=sid,status='REFERENCE_ERROR',error=repr(exc)))
            check('G-RECOVERED-070',sid,'recovered reference exception: '+repr(exc),status='OPEN_REFERENCE')
    (ROOT/'evidence/recovered_replay_results.json').write_text(json.dumps(results,indent=2,default=str))


def check_recovered_laws(check):
    base='hmt_substrate_recovered.admission.'
    o=importlib.import_module(base+'orbital_replay_grade_symbolic_transfer')
    h=importlib.import_module(base+'hypersonic_replay_grade_symbolic_transfer')
    oc=o.DARTReplayFormulaConfig();hc=h.HypersonicReplayFormulaConfig()
    cases=[
        ('orbital far-window ratio',o.nav_covariance_ratio(3601,100,oc),1),
        ('orbital zero target scale',o.nav_covariance_ratio(0,0,oc),1),
        ('orbital reference boresight deg',o.boresight_shift_deg_from_power(7,oc),.001),
        ('orbital zero flex',o.rosa_flex_covariance_multiplier(0,1,oc),1),
        ('orbital peak flex',o.rosa_flex_covariance_multiplier(5,1,oc),1.35),
        ('orbital desat threshold',o.reaction_wheel_desat_pressure(.85,oc),0),
        ('orbital desat upper bound',o.reaction_wheel_desat_pressure(1,oc),.4),
        ('plasma m-3 to cm-3 conversion',h.plasma_cutoff_frequency_hz(1e12),8.98e6),
        ('plasma zero density',h.plasma_cutoff_frequency_hz(0),0),
        ('plasma reference density',h.electron_density_proxy_m3(8,30000,0,hc),7e16),
        ('warp reference state',h.thermal_warp_factor(900,0,hc),1),
        ('warp floor',h.thermal_warp_factor(10000,1200,hc),.35),
        ('atmosphere upper multiplier',h.upper_atmosphere_density_multiplier(55000,1,hc),1.1),
        ('FADS upper mismatch',h.fads_mismatch_pressure(2,hc),.18),
    ]
    evidence=[]
    for subject,actual,expected in cases:
        assert math.isclose(float(actual),expected,rel_tol=1e-10,abs_tol=1e-12),subject
        evidence.append(dict(subject=subject,actual=float(actual),expected=expected,status='PASS'))
        check('G-RECOVERED-071',subject,'independent limiting/reference case; not calibration')
    (ROOT/'evidence/recovered_formula_checks.json').write_text(json.dumps(evidence,indent=2))
