import marimo

__generated_with = "0.25.2"
app = marimo.App(width="medium", app_title='Wounds · effects, time, and compatibility')

@app.cell
def _():
    import marimo as mo
    from pathlib import Path
    import sys
    _root=Path(__file__).resolve().parent
    if str(_root) not in sys.path:
        sys.path.insert(0,str(_root))
    from Resources import WOUNDS, catalog
    mo.md((_root/"Resources/wounds_lesson.md").read_text())
    return mo, WOUNDS, catalog

@app.cell
def _(mo, WOUNDS):
    mo.ui.table([dict(id=k,**v) for k,v in WOUNDS.items()],selection=None,page_size=20)
    return

@app.cell
def _(mo, catalog):
    platform=mo.ui.dropdown({p["title"]:p["id"] for p in catalog()},value="Jackal stopping and traction",label="Substrate")
    platform
    return (platform,)

@app.cell
def _(mo, platform, WOUNDS, catalog):
    _p=next(p for p in catalog() if p["id"]==platform.value)
    mo.ui.table([dict(wound=k,compatible=_p["strategy"] in v["strategies"],affected_quantity=v["field"],unit=v["unit"]) for k,v in WOUNDS.items()],selection=None,page_size=20)
    return

if __name__ == "__main__":
    app.run()
