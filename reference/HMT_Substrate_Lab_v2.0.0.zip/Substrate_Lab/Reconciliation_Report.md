# Substrate Lab v2.0.0 · reconciliation and verification

The six-stage release provides 25 Marimo notebooks, 20 selectable configurations, 14 wound mechanisms, one typed composition interface, and an offline reader. All 18 original registry identities map to a documented successor. The original 113 files, 417 function/method surfaces, and 398 dataclass-default fields remain preserved and inspectable.

## Claim boundary

The active models are verified analytical reductions and explicit synthetic policies. They are not advertised as equivalent replacements for every full legacy replay model. Four original replay paths have reproducible interface incompatibilities. The explicit recovered layer executes 17 of 18 paths using original orbital/hypersonic transfers and a nullable maritime report patch. Panda remains an open interface boundary. Calibration and full-model equivalence remain unclaimed.

## Execution of the six stages

| Stage | Delivered result | Evidence |
|---|---|---|
| 1 · Baseline | Source hashes, 18-entry map, 417-surface inventory, original archive | source_inventory.json; reconciliation.json; legacy_symbol_crosswalk.json |
| 2 · Semantics | Native quantities, strict units/types/bounds, policy separated from physical limits | catalog.json; contracts.py; check_dimensions.py |
| 3 · Fidelity | 22 primary-source records; explicit board/silicon variants; field-level status; open research preserved | sources.json; legacy_field_inventory.json; notebook evidence sections |
| 4 · Tracers | Pi boundary, invalid observations, independent traction/compute effects, source payload propagation | tracer_results.json; G-COUPLING-006; G-REPLAY-018 |
| 5 · Verification | 725 recorded checks: 720 PASS and 5 OPEN_REFERENCE | verification.json; content-addressed snapshots; continuity.sqlite |
| 6 · Reuse | Domain notebooks, wound explorer, composition lab, evidence explorer, general builder, JSON CLI | numbered notebooks; Runbook.md; Agents.md; browser/execution reports |

## Concrete changes

- A single catalog replaces the two-entry versus eighteen-entry selection split. Existing identities remain aliases where their meaning is retained. The ambiguous TI hybrid ID is rejected for new composition and requires an explicit silicon/board selection.
- Pi 70/78/85 C wound thresholds are explicit policy; manufacturer throttling is separately sourced. Temperature headroom uses differences, never a ratio of Celsius coordinates.
- The TI hybrid is split into an explicit custom TDA4VM 8 GB target, with separate AI-64 4 GB and AM68A custom 8 GB configurations. Silicon core counts do not imply application-core availability.
- Jackal mass attribution, REMUS model identity, Panda/FER torque limits, JPL Earth GM conversion, Jetson power-mode distinctions, and current BE-4 configuration are documented without converting unrelated sources into calibration claims.
- Source-backed reference factories now honor their complete dotted path and require explicit arguments. This exposed three incompatible transfer interfaces previously hidden behind default constructors.
- Required observations, exact unit tags, vector sizes, integer counts, finite values, and input bounds are enforced. Scenario effects are checked against their applicable envelope.
- Wounds use native quantities, explicit timing, and deterministic composition. Same-field collisions are rejected. Full capability loss has an explicit limiting-case result.
- Formula comparisons use independently evaluated expressions. BO-NG-EQ-003 receives an explicit symbolic binding correction, with its original declaration retained.

## Original failures and recovered dispositions

| Reference | Original initiating condition | Recovered disposition and remaining evidence |
|---|---|---|
| Maritime | Wound constructor omits four required assessment fields | Executes with omitted assessments explicitly null; source evidence still needed to populate them |
| Panda | Transfer config and callable signatures differ from caller | Version-matched replay API, torque conventions, and source datasets |
| DART/orbital | Transfer config lacks expected covariance fields; callable arities differ | Original transfer recovered and executes; dated navigation/power data and covariance/sigma interpretation remain open |
| Hypersonic | Transfer config lacks expected band fields; callable signatures differ | Original transfer recovered and executes; coefficient calibration and applicability remain open |

The raw frozen archive is unchanged. The four original failures and one remaining recovered failure are separate records, not five distinct broken models. These boundaries do not indicate failed active-model calculations. The synthetic operator model also remains explicitly uncalibrated; no biological constants have been promoted to measured fact.

## Recovered research

`Resources/evidence/Recovered_Research.zip` retains exact recovered orbital, hypersonic, and Jackal transfers plus a reported Pi timing summary. Its manifest contains provenance and hashes. The recovered layer changes only an isolated temporary copy; the original archive is untouched. Jackal remains archival because its original transfer adds SciPy/Pydantic. Pi timing measurements lack sufficient conditions to fit a thermal-latency model.

Orbital covariance-ratio naming conflicts with linear standard-deviation scaling. Hypersonic symbolic attenuation fixes exponent two while the runtime allows other configured exponents. Both remain explicit semantic boundaries. Fourteen independent reference/boundary cases establish arithmetic behavior, not empirical fidelity.

## Verification scope

The gates include all 280 substrate–wound combinations (compatible execution or required rejection), all 75 plant/compute combinations, every active field's numeric bounds/types/shapes, alias resolution, immutable nested data, configuration round trips, time boundaries, source injection, and independent physical identities. Ground stopping is the only implemented compute-to-plant physical coupling; other compositions state parallel assessment.

All 25 Marimo notebooks passed static checks and executed to HTML. Live controls were exercised for all 20 domain notebooks; the four laboratory notebooks passed eight desktop/mobile checks, including builder rejection and export. The offline reader passed 40 domain/viewport checks with no external network requests.

The source inventory is verified byte-for-byte against the preserved archive. Legacy replay execution is a compatibility witness, not empirical validation. Independent formula comparison at declared sample points is not a proof over an entire domain. Structural checks enforce active modules below 180 lines and functions below 60 lines.

A physical-fidelity upgrade requires configuration-specific measurement or a qualified dataset, declared units/frames and uncertainty, an identifiable fit, held-out comparison, and a versioned applicability envelope. Missing research data remain explicit handoff work.
