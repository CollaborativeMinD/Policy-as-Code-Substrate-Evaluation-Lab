"""Human-readable contracts, sources, and compact engineering figures."""
import base64
import io
import json
from matplotlib.figure import Figure
from .registry import ROOT, select


def table(rows):
    if not rows:return 'No records.'
    keys=list(rows[0]);lines=['| '+' | '.join(keys)+' |','|'+'---|'*len(keys)]
    lines += ['| '+' | '.join(str(r[k]).replace('|',' / ').replace('\n',' ') for k in keys)+' |' for r in rows]
    return '\n'.join(lines)


def contracts(identity):
    p=select(identity);blocks=[]
    for title,key in [('Model parameters','parameters'),('Required observations','inputs')]:
        rows=[dict(quantity=f['name'],unit=f['unit'],type=f['kind'],bounds=f"[{f['lower']}, {f['upper']}]",example=f['default'],basis=f['basis']) for f in p[key]]
        blocks.append('### '+title+'\n\n'+table(rows))
    return '## Quantities, units, types, and bounds\n\n'+ '\n\n'.join(blocks)+'\n\nBounds define the teaching envelope, not a certified platform envelope. Examples are selected explicitly with `example(config)`; `evaluate` never supplies missing observations.'


def evidence(identity):
    p=select(identity);sources=json.loads((ROOT/'sources.json').read_text());ids=set(p['sources'])
    ids.update(f['source'] for f in p['parameters'] if f['source'])
    if 'mass_kg' in p['facts'] and isinstance(p['facts']['mass_kg'],dict):ids.add('JACKAL-MASS')
    text='## Evidence and configuration identity\n\n'
    if p['facts']:text+='```json\n'+json.dumps(p['facts'],indent=2)+'\n```\n\n'
    for key in sorted(ids):
        s=sources[key];text+=f"- [{s['title']}]({s['url']}) — {s['locator']}. {s['supported_claim']} Reviewed {s['reviewed']}.\n"
    if not ids:text+='No biological calibration is promoted. This is an explicitly synthetic teaching model.\n'
    return text+'\nA source citation supports only the stated claim. Scenario values and policy choices remain separately labeled.'


def legacy(identity):
    p=select(identity)
    rows=json.loads((ROOT/'evidence/legacy_registry.json').read_text())
    row=next(r for r in rows if r['substrate_id']==p['legacy_source_id'])
    result='## Continuity with the original profile\n\n'
    result+=f"Original identity: `{row['substrate_id']}`. Factory: `{row['profile_factory']}`.\n\n"
    result+='The complete original module, wound logic, source anchors, embedded payloads, and field defaults are preserved in the evidence archive. The canonical lesson is the stated reduction; it is not a replacement for every original replay behavior.\n\n'
    result+='**Original model seam:** '+row['primary_control_law_seam']+'\n\n'
    result+='**Original non-claim boundary:** '+row['non_claim_boundary']+'\n\n'
    path=ROOT/'evidence/legacy_replay_results.json'
    if path.exists():
        test=next(t for t in json.loads(path.read_text()) if t['id']==row['substrate_id'])
        result+='**Frozen replay check:** '+test['status']+'. '+test.get('error','The nominal call executed; this does not calibrate its math.')
    path=ROOT/'evidence/recovered_replay_results.json'
    if path.exists():
        test=next(t for t in json.loads(path.read_text()) if t['id']==row['substrate_id'])
        result+='\n\n**Recovered replay check:** '+test['status']+'. '+test.get('error','The recovered nominal call executed; unknown report fields remain null. This is not physical calibration.')
    return result


def figure(result):
    f=Figure(figsize=(7.2,4.2),layout='constrained');ax=f.subplots()
    ax.plot([r['severity'] for r in result['rows']],[float('nan') if r['value'] is None else r['value'] for r in result['rows']],color='#007f82',linewidth=2)
    selected=result['receipt']['metrics'][result['card']['metric']]
    if selected is not None:
        ax.scatter([result['config']['wounds'][0]['severity']],[selected],color='#b34d28',s=65,zorder=3,label='Selected case')
        ax.legend(fontsize=9)
    ax.set(xlabel='Injected wound severity [1]',ylabel=result['ylabel']);ax.grid(alpha=.2)
    return f


def composition_figure(result):
    f=Figure(figsize=(7.2,4.5),layout='constrained');ax=f.subplots()
    for key in ['stopping_distance_m','clearance_margin_m']:
        ax.plot([r['time_s'] for r in result['rows']],[float('nan') if r[key] is None else r[key] for r in result['rows']],label=key)
    ax.set(xlabel='Scenario time [s]',ylabel='Distance [m]');ax.grid(alpha=.2);ax.legend(fontsize=9)
    return f


def svg_uri(fig):
    with io.BytesIO() as buf:
        fig.savefig(buf,format='svg',metadata={'Creator':'HMT Substrate Lab'})
        return 'data:image/svg+xml;base64,'+base64.b64encode(buf.getvalue()).decode()


def metric_rows(receipt):
    return [dict(metric=k,value=v,unit=receipt['units'][k]) for k,v in receipt['metrics'].items()]
