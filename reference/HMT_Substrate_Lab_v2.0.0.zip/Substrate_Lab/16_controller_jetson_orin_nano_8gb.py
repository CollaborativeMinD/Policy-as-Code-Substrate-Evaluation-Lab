import marimo

__generated_with = "0.25.2"
app = marimo.App(width="medium", app_title='Jetson Orin Nano compute policy')

@app.cell
def _():
    import marimo as mo
    import sys
    from pathlib import Path
    _root = Path(__file__).resolve().parent
    if str(_root) not in sys.path:
        sys.path.insert(0,str(_root))
    from Resources.experiments import lesson, explore
    from Resources.presentation import contracts, evidence, legacy, figure, metric_rows
    return mo, lesson, explore, contracts, evidence, legacy, figure, metric_rows

@app.cell
def _(lesson):
    card = lesson(16)
    return (card,)

@app.cell
def _(mo, card):
    mo.md(card["sections"][0])
    return

@app.cell
def _(mo, card):
    mo.md(card["sections"][1])
    return

@app.cell
def _(mo, card):
    mo.md(card["sections"][2])
    return

@app.cell
def _(mo, card):
    mo.md(card["sections"][3])
    return

@app.cell
def _(mo, contracts, card):
    mo.md(contracts(card["id"]))
    return

@app.cell
def _(mo, card):
    severity = mo.ui.slider(0,1,step=.05,value=.25,label="Injected " + card["wound"] + " severity")
    mo.vstack([mo.md("## Worked experiment\nThe controls select an explicit teaching scenario. Move the wound severity, then inspect the quantities and receipt."),severity])
    return (severity,)

@app.cell
def _(card, severity, explore):
    result = explore(card["number"],severity.value)
    return (result,)

@app.cell
def _(mo, result, metric_rows):
    mo.vstack([mo.md("**Assessment:** " + result["receipt"]["disposition"]),mo.ui.table(metric_rows(result["receipt"]),selection=None)])
    return

@app.cell
def _(figure, result):
    figure(result)
    return

@app.cell
def _(mo, result):
    mo.accordion({"Resolved configuration":mo.json(result["config"]),"Full evaluation receipt":mo.json(result["receipt"]),"Computed sweep":mo.ui.table(result["rows"],selection=None)})
    return

@app.cell
def _(mo, card):
    mo.md(card["sections"][6])
    return

@app.cell
def _(mo, card):
    mo.md(card["sections"][7])
    return

@app.cell
def _(mo, evidence, card):
    mo.md(evidence(card["id"]))
    return

@app.cell
def _(mo, legacy, card):
    mo.accordion({"Original profile and replay boundary": mo.md(legacy(card["id"]))})
    return

if __name__ == "__main__":
    app.run()
