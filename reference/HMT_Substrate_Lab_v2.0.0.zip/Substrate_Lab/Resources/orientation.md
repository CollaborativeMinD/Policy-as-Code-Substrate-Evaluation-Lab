# Substrate Lab

**Choose the physical configuration. State the wound. Inspect the consequences.**

This collection completes the substrate layer of the Digital Twin lab as a set of worked engineering notebooks. It reconciles the 18 legacy entries into 20 selectable configurations: the TI hybrid is made explicit, with separate BeagleBone AI-64 and AM68A targets. Twenty domain notebooks share one catalog and one composition contract; four laboratory notebooks explain wounds, composition, and evidence continuity.

## A small reading path

1. Open your substrate notebook. Predict the outcome before moving the disturbance control.
2. Read the native quantities and derivation. Distinguish published facts from scenario values and policy.
3. Open `21_Wounds.py` to check compatible effects and timing.
4. Use `22_Composition_Lab.py` to see traction and thermal delay interact.
5. Use `24_Configuration_Builder.py` to select any supported combination.
6. Carry the resolved configuration and receipt into a derivative. Use `23_Evidence_and_Continuity.py` to inspect the original research and unresolved contracts.

## Four concepts

| Concept | Purpose |
|---|---|
| Substrate | Identity, parameters, required observations, equations, and applicability |
| Wound | A named change in a native quantity, with explicit severity and timing |
| Registry | The single source for selection, aliases, units, bounds, and evidence |
| Composition interface | The same `compose` / `evaluate` path for a person or an agent |

The canonical calculations use Python's standard library. Marimo and Matplotlib provide the notebook controls and plots. NumPy is needed only for the opt-in legacy replay checks; SymPy is a verification extra. The supplied HTML reads offline without an installation.

## What is established

The active calculations are bounded analytical models and explicit synthetic policies. They have executable contract, identity, composition, and mathematical checks. Published facts have field-level attribution. The original 113 files and 417 function/method surfaces are preserved, with their own dispositions.

**The full legacy replay models are not all qualified.** The original bundle exposes four schema/API failures; the explicit recovered layer restores three paths while Panda remains open. A New Glenn formula declaration needed an explicit symbolic-name correction. These findings remain visible alongside the working canonical models. A reduced equation is not silently labeled equivalent to a full vehicle model.

The source archive retains original use-case and governance vocabulary for continuity; the live collection focuses on mathematical models, not a wargame harness. No healthy telemetry is invented when observations are missing, and no generic pressure vector substitutes for domain quantities.

The former combined TI identifier is retained in the migration record but rejected for new composition: choose the explicit TDA4VM, AI-64, or AM68A configuration.
