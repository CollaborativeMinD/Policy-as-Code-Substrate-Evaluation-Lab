"""Frozen-reference compatibility and independent declared-formula comparison."""
import importlib
import json
import math
from .registry import ROOT
from .replay import load_reference, reference_wound, reference_root, serialize

FACTORIES = {
 'maritime.remus100.v10': {'coeffs':'PRESTERO_REMUS100_HYDRODYNAMICS','acoustic_truth':'MARITIME_ACOUSTIC_NAV_TRUTH'},
 'orbital.dart_nextc_rosa.v4': {'payload':'ORBITAL_DART_RECONSTRUCTION','smart_nav_payload':'SMART_NAV_LOGIC'},
 'drone.iris_ardupilot.v4': {'profile':'IRIS_SITL_PROFILE'},
 'robotic.franka_panda.v4': {'payload':'ROBOTIC_PANDA_DYNAMICS'},
 'ugv.clearpath_jackal.v3': {'profile':'CLEARPATH_JACKAL_PROFILE'},
 'hypersonic.x43a.v5': {'payload':'HYPERSONIC_X43_BASELINE'},
}
INPUTS = {
 'maritime.remus100.v10': dict(speed_m_s=1,depth_m=20,duration_s=1),
 'orbital.dart_nextc_rosa.v4': dict(altitude_km=550,duration_s=1),
 'drone.iris_ardupilot.v4': dict(throttle=.45,duration_s=1),
 'robotic.franka_panda.v4': dict(backlash_mm=.001,torque_load_pct=20,joint_temp_c=30,current_ripple_a=.1,duration_s=1),
 'ugv.clearpath_jackal.v3': dict(commanded_linear_m_s=.8,commanded_angular_rad_s=.1,duration_s=1),
 'hypersonic.x43a.v5': dict(mach=5,altitude_m=25000,duration_s=1),
 'wetware.mammalian.operator.v1': dict(cognitive_load=.2,duration_s=1),
 'controller.raspberry_pi5_8gb.v1': dict(thermal_c=79,memory_pct=40),
 'controller.jetson_orin_nano_8gb.v1': dict(thermal_c=50,memory_pct=40),
}


def check_reference(check):
    rows=json.loads((ROOT/'evidence/legacy_registry.json').read_text());results=[]
    for row in rows:
        sid=row['substrate_id']; payload=row['embedded_payloads']
        args={k:payload[v] for k,v in FACTORIES.get(sid,{}).items()}
        try:
            profile=load_reference(sid,factory_arguments=args or None)
            result=reference_wound(sid,profile,INPUTS.get(sid,{}))
            results.append(dict(id=sid,status='EXECUTED',result=result,
                                config=serialize(getattr(profile,'config',profile))))
            check('G-LEGACY-020',sid,'factory and wound call executed; not model qualification')
        except Exception as exc:
            results.append(dict(id=sid,status='REFERENCE_ERROR',error=repr(exc)))
            check('G-LEGACY-020',sid,'legacy exception preserved: '+repr(exc),status='OPEN_REFERENCE')
    (ROOT/'evidence/legacy_replay_results.json').write_text(json.dumps(results,indent=2,default=str))


def check_declared_formulas(check):
    # SymPy is a verification extra, never an import of the production resolver.
    import sympy as sp
    reference_root();records=[]
    rows=json.loads((ROOT/'evidence/legacy_registry.json').read_text())
    for row in rows:
        module=importlib.import_module(row['profile_module'].replace('substrate_profiles_registry','hmt_substrate_bundle',1))
        for value in vars(module).values():
            if not isinstance(value,tuple):continue
            for f in value:
                if type(f).__name__!='FormulaSpec':continue
                try:
                    symbols={v:sp.Symbol(v,real=True) for v in f.variables}
                    expression=f.symbolic
                    repaired=f.equation_id=='BO-NG-EQ-003' and expression=='(deadline - latency)/deadline'
                    if repaired:
                        expression='(deadline_ms - latency_ms)/deadline_ms'
                    expr=sp.sympify(expression,locals={**symbols,'max':sp.Max,'min':sp.Min,'abs':sp.Abs})
                    expected=float(expr.subs(dict(zip(symbols.values(),f.sample_values))))
                    actual=float(f.runtime_fn(*f.sample_values))
                    passed=math.isfinite(actual) and math.isclose(actual,expected,rel_tol=1e-9,abs_tol=1e-9)
                    record=dict(id=f.equation_id,actual=actual,independent=expected,delta=actual-expected,status='PASS' if passed else 'MISMATCH',
                                binding_repair=expression if repaired else None,original_expression=f.symbolic)
                except Exception as exc:
                    record=dict(id=f.equation_id,status='UNRESOLVED_EXPRESSION',error=str(exc))
                records.append(record)
                check('G-PARITY-021',row['substrate_id']+'/'+f.equation_id,record['status'],
                      status='PASS' if record['status']=='PASS' else 'OPEN_REFERENCE')
    (ROOT/'evidence/declared_formula_comparison.json').write_text(json.dumps(records,indent=2))
