"""Every declared field receives type and bound checks independent of its consumer."""
from . import catalog,compose,example,evaluate
from .contracts import quantity,ContractError
from .check_contracts import rejected


def check_bounds(check):
    for profile in catalog():
        for f in profile['parameters']+profile['inputs']:
            def shape(v):return [v]*7 if f['kind']=='vector7' else v
            quantity(shape(f['lower']),f);quantity(shape(f['upper']),f)
            rejected(lambda: quantity(shape(f['lower']-max(1,abs(f['lower']))),f))
            rejected(lambda: quantity(shape(f['upper']+max(1,abs(f['upper']))),f))
            for v in [True,'1',None,float('nan'),float('inf')]:
                rejected(lambda: quantity(shape(v),f))
            if f['kind']=='integer':rejected(lambda: quantity(f['lower']+.5,f))
            if f['kind']=='vector7':
                rejected(lambda: quantity([1]*6,f));rejected(lambda: quantity([1]*8,f))
            check('G-BOUNDS-050',profile['id']+'.'+f['name'],'closed bounds, type, finite, and shape witnesses')
    c=compose('controller.raspberry_pi5_8gb.v1',wounds=[dict(id='thermal_rise',severity=1)])
    x=example(c);x['temperature_c']=149
    rejected(lambda: evaluate(c,x))
    check('G-ENVELOPE-051','post-wound input','out-of-envelope effect rejected instead of clipped')
    rejected(lambda: compose([],compute_overrides=[]))
    rejected(lambda: compose('ugv.clearpath_jackal.v3',compute_overrides=[]))
    rejected(lambda: compose('ugv.clearpath_jackal.v3',source_ref=7))
    rejected(lambda: compose('ugv.clearpath_jackal.v3',wounds=[dict(id=[],severity=.5)]))
    rejected(lambda: compose('controller.tda4vm_am68a_8gb.v1'))
    check('G-TYPES-052','resolver metadata','strict identity, override, provenance, and wound types')
