# Wounds: mechanisms before labels

A wound **changes a specified quantity**. An assessment **interprets the resulting state**. Keeping them distinct lets the same disturbance support several models without duplicating assessment code.

For retained capability, severity $s\in[0,1]$ gives:

$$p_{effective}=p_0(1-s).$$

For an additive disturbance with declared scale $k$:

$$x_{effective}=x_0+ks.$$

The scale carries the affected unit. A thermal rise uses kelvin differences; an RF fade uses decibels. The supplied scales are scenario choices, not measured damage laws. Severity is neither probability nor a universal cross-domain trauma measure.

## Timing

Every effect has an onset, an optional linear rise, an optional end, and an optional linear recovery. Before onset, severity is zero. With no end, the effect persists. A zero recovery duration removes the scenario effect at its end. This is reversible fault injection; it does not claim that damaged hardware heals.

At positive rise duration $t_r$, the rising factor is:

$$r(t)=\min(1,\max(0,(t-t_0)/t_r)).$$

Recovery is permitted only after the full rise. All times are nonnegative seconds. The resolver rejects a malformed sequence.

## Combining effects

Effects on different quantities commute and are sorted into a canonical order. Two effects on the same target and field are rejected, including duplicate wounds. A future additive or multiplicative aggregation policy must be declared and tested before this restriction changes. Unknown wounds and unsupported substrate–wound pairs are rejected.

Observation bounds remain active after injection. An effect that pushes the scenario beyond its declared model envelope raises a contract error; it is not silently clipped. A capability loss with a defined limiting case, such as zero braking traction, receives an explicit outcome.
