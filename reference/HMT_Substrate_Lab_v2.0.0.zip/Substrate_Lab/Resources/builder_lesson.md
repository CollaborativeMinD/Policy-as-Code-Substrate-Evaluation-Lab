# Build a substrate-bound configuration

Open `24_Configuration_Builder.py` to select a substrate, compatible wounds, and an optional compute component. Edit observations and parameter overrides, inspect the native quantities and receipt, then download the configuration. The initial values are teaching fixtures; replace them for your experiment.

The builder calls the same `compose` and `evaluate` functions used by agents. No per-combination adapters are required. It rejects conflicting wound effects and unsupported fields. A configuration records the catalog, executable implementation, source index, parameter provenance, and exact scenario choices.

```python
from Resources import compose, example, evaluate
config = compose(
    'ugv.clearpath_jackal.v3',
    compute='controller.raspberry_pi5_8gb.v1',
    wounds=[{'id': 'traction_loss', 'severity': 0.5}],
)
observations = example(config)  # teaching fixture, not telemetry
receipt = evaluate(config, observations)
```

Ground stopping includes the selected compute-stage latency. Other compositions state parallel assessment explicitly. Inspect that relationship before deriving a combined model. Use the Runbook's JSON CLI when a notebook session is unnecessary.
