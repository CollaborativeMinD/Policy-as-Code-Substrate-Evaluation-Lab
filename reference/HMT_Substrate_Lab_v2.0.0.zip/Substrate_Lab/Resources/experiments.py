"""Deterministic examples shared by the live notebooks and offline reader."""
import json
from .registry import ROOT, compose, example
from .evaluate import evaluate


def lessons():
    return json.loads((ROOT/'lessons.json').read_text())


def lesson(number):
    return next(c for c in lessons() if c['number']==number)


def explore(number,severity=.25):
    card=lesson(number)
    config=compose(card['id'],wounds=[dict(id=card['wound'],severity=severity)])
    receipt=evaluate(config,example(config));rows=[]
    for i in range(21):
        s=i/20;c=compose(card['id'],wounds=[dict(id=card['wound'],severity=s)])
        r=evaluate(c,example(c))
        rows.append(dict(severity=s,value=r['metrics'][card['metric']],disposition=r['disposition']))
    return dict(card=card,config=config.to_dict(),receipt=receipt,rows=rows,
                ylabel=card['metric']+' ['+receipt['units'][card['metric']]+']')


def composition(severity=.5,time_s=20):
    wounds=[dict(id='traction_loss',severity=severity,onset_s=10,rise_s=10,end_s=60,recovery_s=20),
            dict(id='thermal_rise',target='compute',severity=severity,onset_s=0,rise_s=20)]
    config=compose('ugv.clearpath_jackal.v3',compute='controller.raspberry_pi5_8gb.v1',wounds=wounds)
    x=example(config);x['compute']['temperature_c']=79
    receipt=evaluate(config,x,time_s=time_s)
    rows=[]
    for t in range(0,101,2):
        r=evaluate(config,x,time_s=t)
        rows.append(dict(time_s=t,stopping_distance_m=r['metrics']['stopping_distance_m'],
                         clearance_margin_m=r['metrics']['clearance_margin_m'],
                         latency_s=r['effective_parameters']['latency_s'],disposition=r['disposition']))
    return dict(config=config.to_dict(),receipt=receipt,rows=rows)
