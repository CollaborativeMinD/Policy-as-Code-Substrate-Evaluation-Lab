"""Independent dimension algebra and additional falsification cases."""
from copy import deepcopy
import math
from . import catalog, compose, example, evaluate, ContractError
from .contracts import canonical
from .check_contracts import rejected

# Base exponents: mass, length, time, temperature, angle/information treated explicitly in metadata.
D={'1':(0,0,0,0),'kg':(1,0,0,0),'m':(0,1,0,0),'s':(0,0,1,0),'K':(0,0,0,1),
   'N':(1,1,-2,0),'Pa':(1,-1,-2,0),'J':(1,2,-2,0),'W':(1,2,-3,0)}


def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def scale(a,n):return tuple(x*n for x in a)


def check_dimensions(check):
    velocity=sub(D['m'],D['s']);acceleration=sub(velocity,D['s'])
    density=sub(D['kg'],scale(D['m'],3));area=scale(D['m'],2)
    assert sub(scale(velocity,2),acceleration)==D['m']
    assert add(density,scale(velocity,2))==D['Pa']
    assert add(D['Pa'],area)==D['N']
    assert add(D['N'],velocity)==D['W']
    assert sub(D['N'],D['kg'])==acceleration
    assert sub(add(D['N'],D['s']),D['kg'])==velocity
    assert sub(D['J'],D['W'])==D['s']
    assert sub(D['W'],sub(D['J'],D['K']))==sub(D['K'],D['s'])
    assert sub(scale(D['m'],3),sub(scale(D['m'],3),scale(D['s'],2)))==scale(D['s'],2)
    assert sub(D['N'],D['N'])==D['1']
    check('G-UNITS-040','native equations','10 independent dimensional identities; logs take dimensionless ratios')
    c=compose('controller.raspberry_pi5_8gb.v1');p=c.to_dict()['parameters'];x=example(c)
    x['temperature_c']=79;r=evaluate(c,x)
    assert r['metrics']['policy_state']=='CONTINGENCY'
    assert math.isclose(r['metrics']['thermal_margin_k'],(p['terminal_c']+273.15)-(79+273.15))
    x['memory_fraction']=.94;assert evaluate(c,x)['metrics']['policy_state']=='TERMINAL_POLICY'
    rejected(lambda: compose(c.to_dict()['substrate']['id'],overrides={'terminal_c':78}))
    check('G-POLICY-041','Pi thresholds','79 C conflict resolved; temperature difference origin-invariant; ordered thresholds')
    c=compose('ugv.clearpath_jackal.v3',wounds=[dict(id='traction_loss',severity=1)])
    x=example(c);assert evaluate(c,x)['disposition']=='CAPABILITY_LOST'
    x['speed_m_s']=0;assert evaluate(c,x)['metrics']['stopping_distance_m']==0
    check('G-LIMIT-042','zero traction','moving: no finite stop; stationary: zero distance')
    c=compose('ugv.clearpath_jackal.v3');x=example(c);x['speed_m_s']=1
    assert math.isclose(evaluate(c,x)['metrics']['wheel_speed_residual_m_s'],-.2)
    check('G-FRAMES-046','wheel/body velocity','signed discrepancy exposed; encoder yaw estimate is separate')


def check_component_matrix(check):
    profiles=catalog();boards=[p for p in profiles if p['strategy']=='compute']
    plants=[p for p in profiles if p['strategy']!='compute']
    for p in plants:
        for board in boards:
            c=compose(p['id'],compute=board['id']);r=evaluate(c,example(c))
            assert r['compute'] is not None
            expected='ground_stopping_latency' if p['strategy']=='ground' else 'parallel_assessment'
            assert r['coupling']==expected
            check('G-COMPONENT-043',p['id']+' + '+board['id'],expected)
    c=compose('robotic.franka_panda.v4');x=example(c);before=canonical(c.to_dict())
    for _ in range(3):evaluate(c,x)
    assert canonical(c.to_dict())==before
    changed=c.to_dict();changed['parameters']['torque_limits_nm'][0]=1
    assert c.to_dict()['parameters']['torque_limits_nm'][0]==87
    check('G-IMMUTABLE-044','repeated evaluation','no config mutation; detached nested vectors')
    rejected(lambda: compose('robotic.franka_panda.v4',source_payload={'joint_dynamics':{'torque_limits':[60]*7,'ignored':1}},source_ref='fixture'))
    check('G-INGRESS-045','Panda payload','unsupported payload fields rejected')
