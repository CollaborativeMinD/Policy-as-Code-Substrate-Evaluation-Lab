"""Build the offline reading edition using optional publishing extras."""
import html
import json
import re
import markdown
from latex2mathml.converter import convert as mathml
from .registry import ROOT
from .experiments import lessons, explore, composition
from .presentation import contracts,evidence,legacy,table,figure,composition_figure,svg_uri,metric_rows
from .wounds import WOUNDS


def convert(text):
    expressions=[]
    def replace(match):
        block=match[1] is not None;value=match[1] if block else match[2]
        rendered=mathml(value.strip(),display='block' if block else 'inline')
        if block:rendered='<div class="formula">'+rendered+'</div>'
        token=f'MATHTOKEN{len(expressions)}END';expressions.append((token,rendered,block))
        return '\n\n'+token+'\n\n' if block else token
    text=re.sub(r'\$\$(.*?)\$\$|(?<!\\)\$([^$\n]+?)\$',replace,text,flags=re.S)
    body=markdown.markdown(text,extensions=['tables','fenced_code'])
    for token,value,block in expressions:
        body=body.replace('<p>'+token+'</p>' if block else token,value)
    return body.replace('<table>','<div class="table-scroll"><table>').replace('</table>','</table></div>')


def detail(title,text):
    return '<details><summary>'+html.escape(title)+'</summary>'+text+'</details>'


def json_view(obj):
    return '<pre>'+html.escape(json.dumps(obj,indent=2))+'</pre>'


def live(card,result):
    content=convert('## Worked experiment\n\nComputed at wound severity 0.25. Change the controls in the companion notebook.\n\n**Assessment:** '+result['receipt']['disposition'])
    content+=convert(table(metric_rows(result['receipt'])))
    content+='<figure><img class="plot" src="'+svg_uri(figure(result))+'" alt="'+html.escape(result['ylabel'])+' versus wound severity"><figcaption>A gap at complete capability loss means no finite result is established.</figcaption></figure>'
    content+=detail('Inspect the computed sweep',convert(table(result['rows'])))
    content+=detail('Resolved configuration and receipt',json_view(result['config'])+json_view(result['receipt']))
    return '<div class="live">'+content+'</div>'


def chapter(card):
    pieces=[];result=explore(card['number'])
    for section in card['sections']:
        if section=='CONTRACTS':pieces.append(convert(contracts(card['id'])))
        elif section=='LIVE':pieces.append(live(card,result))
        elif section=='EVIDENCE':pieces.append(convert(evidence(card['id'])))
        elif section=='LEGACY':pieces.append(detail('Original model and replay boundary',convert(legacy(card['id']))))
        else:pieces.append(convert(section))
    return '<article class="chapter" id="'+card['slug']+'">'+''.join(pieces)+'</article>'


def laboratories():
    wound=convert((ROOT/'wounds_lesson.md').read_text())
    wound+=convert(table([dict(wound=k,quantity=v['field'],unit=v['unit'],operation=v['mode'],strategies=', '.join(v['strategies'])) for k,v in WOUNDS.items()]))
    result=composition();comp=convert((ROOT/'composition_lesson.md').read_text())
    comp+='<figure><img class="plot" src="'+svg_uri(composition_figure(result))+'" alt="Stopping and clearance distance through wound onset and recovery"></figure>'
    comp+=detail('Inspect the time trace',convert(table(result['rows'])))
    comp+=detail('Inspect the complete composed receipt',json_view(result['receipt']))
    ev=convert((ROOT/'evidence_lesson.md').read_text())
    report=json.loads((ROOT/'evidence/verification.json').read_text())
    ev+=convert(table([r for r in report if r['status']!='PASS']))
    ev+=detail('Full original research catalog',json_view(json.loads((ROOT/'evidence/legacy_registry.json').read_text())))
    return ''.join('<article class="chapter" id="'+key+'">'+body+'</article>' for key,body in [('wounds',wound),('composition',comp),('evidence',ev),('builder',convert((ROOT/'builder_lesson.md').read_text()))])


def main():
    cards=lessons();css=(ROOT/'reader.css').read_text()
    nav=''.join('<a href="#'+c['slug']+'">'+str(c['number']).zfill(2)+' · '+html.escape(c['title'])+'</a>' for c in cards)
    nav+='<a href="#wounds">21 · Wounds</a><a href="#composition">22 · Composition lab</a><a href="#evidence">23 · Evidence</a><a href="#builder">24 · Configuration builder</a>'
    intro=convert((ROOT/'orientation.md').read_text())
    body='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HMT Substrate Lab · v2.0.0</title><style>'+css+'</style></head><body><header><div class="eyebrow">HMT · Digital Twin Lab · v2.0.0</div><h1>Substrates, wounds,<br>and visible consequences</h1><p>Twenty configurations. One composition contract. Evidence beside the equations.</p><span class="pill">Offline reading edition · computed cases · explicit fidelity boundaries</span></header><div class="layout"><aside><a href="#start">Start here</a><nav>'+nav+'</nav></aside><main id="start">'+intro+''.join(chapter(c) for c in cards)+laboratories()+'<footer>The companion includes 25 executable Marimo notebooks, a standard-library modeling core, the full original source archive, and reproducible evidence. Physical calibration remains scoped to available data.</footer></main></div></body></html>'
    (ROOT.parent/'Substrate_Lab_Reader.html').write_text(body)
    print('Published',len(cards),'domain chapters and 4 laboratories')


if __name__=='__main__':main()
