# Evidence that survives handoff

A parameter needs more than a value. It needs a unit, type, domain, source or assumption, and an applicability boundary. The catalog records those fields for every active parameter and observation. Source notes identify what the cited document actually supports.

| Basis | Interpretation |
|---|---|
| PUBLISHED | A stated specification or constant tied to the selected source |
| CONVENTION | A declared approximation or reference convention |
| LEGACY_ASSUMPTION | A retained value whose calibration is not established |
| SCENARIO | An explicit teaching or experiment setting |
| POLICY | A selected assessment boundary, not a physical law |
| USER_SUPPLIED | A parameter override or supplied payload; not automatically calibrated |

No statistical uncertainty distribution is fabricated. Uncertainty propagation requires source bounds or measurements; interval/sensitivity experiments can be added without relabeling assumptions as data.

## A source-injection witness

```python
from Resources import compose, example, evaluate

config = compose(
    "robotic.franka_panda.v4",
    source_payload={"joint_dynamics": {
        "torque_limits": [60, 87, 87, 87, 12, 12, 12]
    }},
    source_ref="synthetic-fixture-60Nm-not-a-manufacturer-update",
)
state = example(config)
state["joint_torque_nm"] = [61, 0, 0, 0, 0, 0, 0]
result = evaluate(config, state)
assert result["metrics"]["minimum_torque_margin_nm"] == -1
```

This proves that source injection reaches the model. It does not prove that a 60 N·m limit describes a real robot. The active injection contract accepts exactly the supported torque vector; extra payload fields are rejected instead of silently ignored.

## Original research and unresolved contracts

The selectors below expose the complete original embedded dictionaries, configuration defaults, and source contracts. The frozen archive retains exact source files and hashes. The optional replay helper honors the complete dotted factory and requires explicit arguments for source-backed constructors.

The untouched bundle has four recorded replay failures. The explicit recovered layer executes 17 of 18 reference paths: original orbital and hypersonic transfer modules restore their caller interfaces, and omitted maritime assessment fields remain null under a documented nullable-report patch. Panda still requires its version-matched transfer implementation. Execution demonstrates compatibility, not physical calibration.

The old formula-parity function checked only finiteness. The new qualification pass independently evaluates declared symbolic expressions with SymPy, compares the numerical results, and records discrepancies. One launch formula declares `latency_ms, deadline_ms` but uses `latency, deadline` in its expression. The comparison record preserves that original expression and verifies the corrected `latency_ms` / `deadline_ms` binding explicitly.

Use `Resources/evidence/continuity.sqlite` for the Cumulative Gate Ledger and Reverse RCA Ledger. Each ledger has seven columns. See the root Runbook for reproducible checks and troubleshooting.


## Recovered research, with its limits

`Recovered_Research.zip` preserves three original transfer modules and the Pi timing summary. `recovered_manifest.json` records identities and byte hashes. Only orbital and hypersonic transfers are installed into the optional recovered replay namespace. The Jackal transfer remains a research reference because it brings SciPy and Pydantic dependencies; its terrain and timing anchors are not silently promoted to measured facts.

The recovered orbital function named `nav_covariance_ratio` scales line-of-sight **standard deviation** linearly. If the factor is intended as a variance ratio, standard deviation would scale by its square root. The intended interpretation remains unresolved. The hypersonic symbolic attenuation declaration fixes the exponent at two, while the runtime permits configuration; its default comparisons do not establish parity for other exponents. Both are explicit fidelity boundaries for future derivations.

The Pi summary reports 12,000 samples, a 10 ms target period, approximately 19.332 μs p95 timing jitter, 75.667 μs p99, and 6.606303 ms maximum. All events are classified `late+net_missing`. Temperature, workload, power mode, firmware, raw samples, and metric definitions are absent. These are reported measurements with incomplete context, not a fitted thermal-latency law. A loop period must not be substituted for compute-stage latency.

Fourteen recovered-formula boundary/reference cases check arithmetic and units. They do not establish measured vehicle fidelity or qualify the legacy modules' permissive input coercions. Use the strict canonical core for new configurations.
