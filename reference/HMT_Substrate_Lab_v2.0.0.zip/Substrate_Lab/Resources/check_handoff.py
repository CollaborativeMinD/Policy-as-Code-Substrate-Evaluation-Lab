"""Artifact integrity, standard-library JSON handoff, and content identity."""
from pathlib import Path
from hashlib import sha256
import json
import subprocess
import sys
import tempfile
import zipfile
from .registry import ROOT
from .contracts import canonical


def check_handoff(check):
    with zipfile.ZipFile(ROOT/'evidence/Legacy_Substrate_Reference.zip') as z:
        for row in json.loads((ROOT/'evidence/source_inventory.json').read_text()):
            assert sha256(z.read('substrate_profiles_registry/'+row['path'])).hexdigest()==row['sha256']
    check('G-ARCHIVE-060','113 original files','every preserved file matches its source hash')
    with tempfile.TemporaryDirectory() as name:
        folder=Path(name);request=folder/'request.json';config=folder/'config.json'
        observations=folder/'observations.json'
        request.write_text(json.dumps({'substrate':'ugv.clearpath_jackal.v3'}))
        def cli(*args):
            return subprocess.run([sys.executable,'-m','Resources.cli',*args],cwd=ROOT.parent,
                                  text=True,capture_output=True,timeout=30)
        result=cli('compose','--request',str(request),'--output',str(config))
        assert result.returncode==0,result.stderr
        result=cli('example','--config',str(config),'--output',str(observations))
        assert result.returncode==0,result.stderr
        result=cli('evaluate','--config',str(config),'--observations',str(observations))
        assert result.returncode==0,result.stderr
        receipt=json.loads(result.stdout);document=json.loads(config.read_text())
        assert receipt['config_hash']==sha256(canonical(document).encode()).hexdigest()
        request.write_text('{"substrate":"a","substrate":"b"}')
        assert cli('compose','--request',str(request)).returncode==2
        request.write_text('{"substrate":"ugv.clearpath_jackal.v3","overrides":{"latency_s":NaN}}')
        assert cli('compose','--request',str(request)).returncode==2
    check('G-CLI-061','JSON handoff','compose, fixture, evaluate, matching hash, duplicate/nonfinite rejection')
