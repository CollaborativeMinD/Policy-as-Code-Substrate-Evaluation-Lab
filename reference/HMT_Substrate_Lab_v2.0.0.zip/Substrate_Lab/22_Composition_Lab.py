import marimo

__generated_with = "0.25.2"
app = marimo.App(width="medium", app_title='Composition laboratory · one contract')

@app.cell
def _():
    import marimo as mo
    from pathlib import Path
    import sys
    _root=Path(__file__).resolve().parent
    if str(_root) not in sys.path:
        sys.path.insert(0,str(_root))
    from Resources.experiments import composition
    from Resources.presentation import composition_figure, metric_rows
    mo.md((_root/"Resources/composition_lesson.md").read_text())
    return mo, composition, composition_figure, metric_rows

@app.cell
def _(mo):
    severity=mo.ui.slider(0,1,step=.05,value=.5,label="Wound severity")
    clock=mo.ui.slider(0,100,step=1,value=20,label="Scenario time [s]")
    mo.hstack([severity,clock])
    return severity, clock

@app.cell
def _(composition, severity, clock):
    result=composition(severity.value,clock.value)
    return (result,)

@app.cell
def _(mo, result, metric_rows):
    mo.vstack([mo.md("**Assessment:** "+result["receipt"]["disposition"]),mo.ui.table(metric_rows(result["receipt"]),selection=None),mo.json(result["receipt"]["compute"])])
    return

@app.cell
def _(composition_figure, result):
    composition_figure(result)
    return

@app.cell
def _(mo, result):
    mo.accordion({"Configuration for agent or derivative":mo.json(result["config"]),"Every applied effect":mo.ui.table(result["receipt"]["applied_wounds"],selection=None),"Full receipt":mo.json(result["receipt"]),"Time trace":mo.ui.table(result["rows"],selection=None)})
    return

if __name__ == "__main__":
    app.run()
