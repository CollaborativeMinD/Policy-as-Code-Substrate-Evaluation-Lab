"""Independent identities, dimensional checks, and limiting-case witnesses."""
import math
from . import compose, example, evaluate
from . import mechanics, fields, response
from .wounds import severity_at


def close(a,b):
    assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10),(a,b)


def check_physics(check):
    c=compose('ugv.clearpath_jackal.v3'); p=c.to_dict()['parameters'];x=example(c)
    for v in [0,.1,.5,1,2]:
        x['speed_m_s']=v;r=mechanics.ground(p,x)
        brake=r['stopping_distance_m']-v*p['latency_s']
        close(2*p['brake_decel_m_s2']*brake,v*v)
    check('G-MATH-010','ground','work-energy braking identity, including zero velocity')
    c=compose('maritime.remus100.v10');p=c.to_dict()['parameters'];x=example(c)
    a=fields.spacecraft({'array_power_w':0,'thrust_n':1,'mass_kg':10},dict(eclipse_fraction=1,sun_angle_deg=0,load_w=100,usable_energy_wh=10,burn_duration_s=2))
    close(a['reserve_time_s'],360);close(a['small_burn_delta_v_m_s'],.2)
    for v in [.1,1,2]:
        x['speed_m_s']=v;r=mechanics.vessel(p,x)
        close(r['propulsive_power_w'],r['drag_n']*v)
        close(r['acceleration_m_s2']*p['mass_kg'],r['net_force_n'])
    check('G-MATH-011','marine/spacecraft','force, work rate, joule-to-Wh, impulse identities')
    c=compose('orbital.coverage.earth_geometry.v1');p=c.to_dict()['parameters'];x=example(c)
    x['elevation_deg']=0;r=fields.coverage(p,x)
    close(r['surface_fraction'],(1-p['radius_m']/(p['radius_m']+x['altitude_m']))/2)
    close((2*math.pi/r['orbital_period_s'])**2*(p['radius_m']+x['altitude_m'])**3,p['mu_m3_s2'])
    x['elevation_deg']=90;close(fields.coverage(p,x)['surface_fraction'],0)
    check('G-MATH-012','coverage','Kepler balance, cap geometry, zenith limit')
    c=compose('radar.xband.public_physics.v1');p=c.to_dict()['parameters'];x=example(c)
    r=fields.radar(p,x);x['range_m']*=2;r2=fields.radar(p,x)
    close(r2['free_space_loss_db']-r['free_space_loss_db'],20*math.log10(2))
    x['snr_db']=0;close(fields.radar(p,x)['channel_capacity_bit_s'],x['bandwidth_hz'])
    close(r['wavelength_m']*x['frequency_hz'],299792458)
    check('G-MATH-013','RF','inverse-square doubling, Shannon 0 dB, c=f lambda')
    c=compose('nuclear.containment.iaea_nrc.v1');p=c.to_dict()['parameters'];x=example(c)
    r=fields.containment(p,x);close((r['temperature_k']-x['initial_temp_k'])*p['thermal_capacity_j_k'],(x['heat_in_w']-p['heat_removal_w'])*x['duration_s'])
    x['heat_in_w']=p['heat_removal_w'];assert fields.containment(p,x)['time_to_limit_s'] is None
    x['initial_temp_k']=p['temp_limit_k'];close(fields.containment(p,x)['time_to_limit_s'],0)
    check('G-MATH-014','thermal','energy conservation, equilibrium, already-at-limit')


def check_remaining(check):
    p=dict(area_m2=2,q_limit_pa=1e5);x=dict(density_kg_m3=1,speed_m_s=10,lift_coefficient=.5,drag_coefficient=.1)
    r=mechanics.aircraft(p,x);close(r['lift_n'],50);close(r['drag_n'],10)
    r=mechanics.rotorcraft(dict(max_thrust_n=40,mass_kg=1,gravity_m_s2=10),dict(throttle_fraction=.5))
    close(r['vertical_acceleration_m_s2'],0)
    r=mechanics.humanoid(dict(gravity_m_s2=10,support_half_width_m=.2),dict(com_height_m=1,com_x_m=0,com_velocity_m_s=0,friction_coefficient=.5,normal_force_n=100,tangent_force_n=-50))
    close(r['support_margin_m'],.2);close(r['friction_margin_n'],0)
    r=mechanics.launch(dict(engine_count=7,engine_thrust_n=100,gravity_m_s2=10),dict(throttle_fraction=1,mass_kg=70))
    close(r['thrust_to_weight'],1);close(r['vertical_force_margin_n'],0)
    check('G-MATH-015','aero/rotor/support/launch','hand-calculated balances and symmetric tangential force')
    p=dict(recovery_time_s=1200,load_gain=1,load_limit=.7)
    r=response.workload(p,dict(duration_s=0,load_fraction=1,initial_load=.2))
    close(r['synthetic_load_state'],.2)
    r=response.workload(p,dict(duration_s=1200,load_fraction=0,initial_load=1))
    close(r['synthetic_load_state'],1/math.e)
    check('G-MATH-016','synthetic workload','initial condition and one-time-constant decay')
    wound=dict(severity=.8,onset_s=10,rise_s=10,end_s=30,recovery_s=10)
    expected=[0,0,.4,.8,.8,.4,0]
    assert [severity_at(wound,t) for t in [0,10,15,20,30,35,40]]==expected
    check('G-TIME-017','wounds','onset, rise, plateau, and recovery boundaries')
    c=compose('robotic.franka_panda.v4',source_payload={'joint_dynamics':{'torque_limits':[60,87,87,87,12,12,12]}},source_ref='synthetic-tracer-v1')
    x=example(c);x['joint_torque_nm']=[61,0,0,0,0,0,0];r=evaluate(c,x)
    close(r['metrics']['minimum_torque_margin_nm'],-1)
    assert r['parameter_provenance']['torque_limits_nm']=='USER_SUPPLIED'
    check('G-REPLAY-018','Panda','payload changes physical limit and provenance')
