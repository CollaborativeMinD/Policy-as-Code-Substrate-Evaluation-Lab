# Agent orchestration and interception interface

## Entry points

Use `Resources.compose`, `Resources.evaluate`, `Resources.import_configuration`, and `Resources.catalog`. The JSON CLI exposes the same contract. Begin with `00_Start_Here.py`, then inspect the selected profile's units, bounds, assumptions, and evidence. The configuration builder is `24_Configuration_Builder.py`.

## Before deriving a model

- Resolve an existing substrate identity and inspect aliases before adding a copy.
- Identify whether each value is published, measured, assumed, scenario-selected, or policy-selected. This release has no secretly calibrated estimates.
- Supply every observation explicitly. `example(config)` is a teaching fixture, not telemetry.
- Preserve dimensional meaning; do not fold energy pressure into temperature or plasma fields.
- Keep measured torque, gravity conventions, and desired torque distinct. Do not treat all difference signals as equivalent residuals.
- Confirm whether composition is physical coupling or parallel assessment.

## Intercept and stop

Reject unknown keys, duplicate JSON keys, nonfinite values, Boolean-as-number, wrong vector shapes, mismatched units, unsupported combinations, conflicting wound effects, invalid timing, and altered configuration identity. Do not bypass these with coercion, nominal defaults, clipping, or constructor fallback.

A failed legacy transfer API is an evidence boundary. Preserve the failure and request/recover the original interface and dataset. Do not invent missing coefficients to make a replay turn green. Synthetic models remain named synthetic; no biological calibration, vehicle validation, or operational authority follows from a finite output.

## Handoff packet

Provide the resolved configuration, full evaluation receipt, source/parameter provenance, catalog version and hash, experiment observations, scope of the claim, validation records, and open evidence. Keep the original source archive and its file inventory together. Check `Reconciliation_Report.md` before claiming equivalence to a legacy surface.

## Checks and maintenance

Run `python -m Resources.verify` after every implementation change; use `--references` when comparing original interfaces or formula declarations. Use `python -m marimo check *.py` and execute affected notebooks. The offline reader must remain network-independent and readable at desktop and phone widths. Follow the Runbook's correction sequence and record causal evidence in the two seven-column SQLite ledgers.

No background agent, network service, or hardware operation is started by this collection. Legacy replay is explicitly requested and local. Keep active modules below 180 lines and functions below 60 lines. Preserve domain mathematics behind the shared interface; do not create per-combination caller adapters.
