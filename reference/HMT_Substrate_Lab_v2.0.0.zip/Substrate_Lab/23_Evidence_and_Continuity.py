import marimo

__generated_with = "0.25.2"
app = marimo.App(width="medium", app_title='Evidence and legacy continuity')

@app.cell
def _():
    import marimo as mo
    from pathlib import Path
    import json
    root=Path(__file__).resolve().parent
    mo.md((root/"Resources/evidence_lesson.md").read_text())
    return mo, root, json

@app.cell
def _(mo, root, json):
    records=json.loads((root/"Resources/evidence/legacy_registry.json").read_text())
    profile=mo.ui.dropdown({r["display_name"]:r["substrate_id"] for r in records},value=records[0]["display_name"],label="Inspect original research")
    profile
    return profile, records

@app.cell
def _(mo, profile, records):
    _r=next(r for r in records if r["substrate_id"]==profile.value)
    mo.accordion({"Original field defaults":mo.json(_r["dataclass_defaults"]),"Embedded research payloads":mo.json(_r["embedded_payloads"]),"Original source and model contracts":mo.json(_r["profile_specs"])})
    return

@app.cell
def _(mo, root, json):
    _rows=json.loads((root/"Resources/evidence/verification.json").read_text())
    mo.ui.table(_rows,selection=None,page_size=15)
    return

@app.cell
def _(mo, root, json):
    _manifest=json.loads((root/"Resources/evidence/recovered_manifest.json").read_text())
    _results=json.loads((root/"Resources/evidence/recovered_replay_results.json").read_text())
    mo.accordion({"Recovered research and provenance":mo.json(_manifest),"Recovered replay results":mo.json(_results)})
    return

if __name__ == "__main__":
    app.run()
