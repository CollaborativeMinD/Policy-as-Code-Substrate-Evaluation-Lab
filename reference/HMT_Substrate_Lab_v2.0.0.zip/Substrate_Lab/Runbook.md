# Substrate Lab · operator runbook

## 1. Open the collection

Open `Substrate_Lab_Reader.html` for offline reading. Start with `00_Start_Here.py` for live work, or open `24_Configuration_Builder.py` to assemble a configuration directly. The active modeling core uses only the Python standard library. Notebook viewing uses Marimo and Matplotlib; no simulator, robot description package, database server, cloud API, or hardware adapter is required.

From the extracted `Substrate_Lab` folder:

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m marimo edit 00_Start_Here.py
```

Windows uses `.venv\Scripts\python` instead. Qualification was performed with Python 3.12.14, Marimo 0.25.2, Matplotlib 3.10.8, NumPy 2.3.5, and SymPy 1.14.0. Other interpreter versions are not claimed as tested.

## 2. Select and evaluate

Use `24_Configuration_Builder.py` for substrate, compatible wound, compute component, observation, and parameter selection. It exports the same configuration and receipt used by the Python and JSON interfaces.

```python
from Resources import compose, example, evaluate
config = compose('ugv.clearpath_jackal.v3',
                 wounds=[{'id':'traction_loss','severity':0.5}])
observations = example(config)  # explicit teaching data; replace for a real case
receipt = evaluate(config, observations)
print(receipt['metrics'])
```

A bare numeric value uses the declared native unit. An explicitly tagged value must use exactly `{"value": 1.2, "unit": "m/s"}`. Units are not guessed or silently converted. Convert an external measurement explicitly before ingress and retain its provenance in the experiment record.

A parameter override is marked USER_SUPPLIED. For Panda torque data, `source_payload` must contain exactly the supported seven-joint torque-limit vector and a nonempty `source_ref`. Extra fields are rejected. Complete historic payloads belong to the explicitly scoped reference replay path below.

## 3. Use the agent/CLI path

Create `request.json` containing `{"substrate":"ugv.clearpath_jackal.v3","wounds":[{"id":"traction_loss","severity":0.5}]}`. Then:

```bash
python -m Resources.cli compose --request request.json --output configuration.json
python -m Resources.cli example --config configuration.json --output observations.json
python -m Resources.cli evaluate --config configuration.json --observations observations.json --output receipt.json
```

`example` deliberately generates a teaching fixture; it is never a fallback inside evaluation. JSON ingress rejects duplicate keys and nonfinite constants. Invalid requests exit with code 2. `catalog` lists all supported identities. A resolved configuration cannot be edited silently: import re-resolves it and compares the complete content with the current catalog.

## 4. Interpret results

| Result | Meaning |
|---|---|
| WITHIN_DECLARED_MODEL | No tested scalar margin is negative and no nonnominal compute policy is selected |
| POLICY_DEGRADED | A declared compute threshold is crossed |
| LIMIT_EXCEEDED | At least one modeled scalar margin is negative |
| CAPABILITY_LOST | No finite stopping distance is established for a moving zero-traction case |
| ContractError / CLI exit 2 | Request, units, bounds, field shape, or model applicability failed |

These are model dispositions, not operating permission. A null spacecraft reserve time means no depletion under the supplied constant balance. A null stopping distance means finite stopping is unavailable. They are different domain meanings, explained beside the equations.

The Jackal + compute composition adds estimated compute-stage delay to a plant reaction interval that excludes that stage. Other plant/compute combinations are parallel assessments, with no implicit physical coupling. Wound end/recovery schedules describe reversible scenario effects, not healing of physical damage.

## 5. Verify and inspect evidence

```bash
python -m Resources.verify
python -m pip install -r Resources/verification-requirements.txt
python -m Resources.verify --references
python -m marimo check *.py
```

The first command runs the active-model checks with no SymPy or legacy imports. The second verification mode also executes frozen and recovered reference probes, independent symbolic comparisons, and recovered boundary cases. OPEN_REFERENCE records are reported separately; the command's successful exit establishes completion of the active checks, not full legacy qualification. Unexpected active assertions stop execution.

`Resources/evidence/verification.json` contains the latest recorded gates. Content-addressed gate snapshots and `continuity.sqlite` preserve cumulative results. Inspect the ledgers using Python's built-in sqlite3:

```python
import sqlite3
db = sqlite3.connect('Resources/evidence/continuity.sqlite')
for row in db.execute('SELECT gate_id, status, count(*) FROM "Cumulative Gate Ledger" GROUP BY gate_id, status'):
    print(row)
for row in db.execute('SELECT incident_id, observed_state, disposition FROM "Reverse RCA Ledger"'):
    print(row)
```

## 6. Replay a preserved original deliberately

```python
from Resources.replay import load_reference, reference_wound, reference_record
row = reference_record('ugv.clearpath_jackal.v3')
profile = load_reference(row['substrate_id'], factory_arguments={
    'profile': row['embedded_payloads']['CLEARPATH_JACKAL_PROFILE']})
legacy = reference_wound(row['substrate_id'], profile, {
    'commanded_linear_m_s': 0.8, 'commanded_angular_rad_s': 0.1, 'duration_s': 1})
```

The helper verifies the frozen archive hash, extracts it to a temporary location, and resolves the entire dotted factory. It refuses a previously imported competing legacy package; restart the Python process in that case. It never falls back from a requested source constructor to an empty constructor. The replay result is explicitly REFERENCE_REPLAY_NOT_PHYSICAL_CALIBRATION.

The untouched bundle has four recorded replay failures. The explicit recovered layer executes 17 of 18 reference paths: original orbital and hypersonic transfer modules restore their caller interfaces, and omitted maritime assessment fields remain null under a documented nullable-report patch. Panda still requires its version-matched transfer implementation. Execution demonstrates compatibility, not physical calibration.

Pass `transfer_version="recovered"` to `load_reference` to opt into that layer. The default `"bundle"` reproduces the untouched source. Recovered records and original failures are recorded separately. Unknown report fields remain null; do not interpret them as healthy values.

## 7. Modify safely

For a data-backed variant, copy a catalog record, assign a distinct ID, update field provenance and applicability, and retain the old ID only when its meaning remains equivalent. For genuinely new physics, add a small strategy implementation with a native output contract and independent witnesses. For a new wound, declare its target field, units, effect, compatible strategies, and timing tests. Same-field composition remains rejected until an explicit aggregation law is verified.

Re-run the cumulative active gates after changes. Preserve the frozen archive. Use the Reverse RCA Ledger for a failure's initiating condition, causal path, fix or evidence boundary, and regression outcome. Active modules must stay below 180 lines and functions below 60 lines; archived originals are frozen references, not edited implementation modules.

To regenerate the reader after a deliberate source change:

```bash
python -m pip install -r Resources/publishing-requirements.txt
python -m Resources.publish
```
