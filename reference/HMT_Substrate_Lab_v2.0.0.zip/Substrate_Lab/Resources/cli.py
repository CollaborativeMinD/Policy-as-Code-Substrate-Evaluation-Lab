"""One JSON interface: catalog, compose, evaluate, and inspect."""
import argparse
import json
from pathlib import Path
from . import catalog,compose,evaluate,import_configuration,example
from .contracts import ContractError


def unique_object(pairs):
    result={}
    for key,value in pairs:
        if key in result:
            raise ContractError('duplicate JSON key: '+key)
        result[key]=value
    return result


def reject_constant(value):
    raise ContractError('nonfinite JSON constant: '+value)


def read(path):
    return json.loads(Path(path).read_text(),object_pairs_hook=unique_object,
                      parse_constant=reject_constant)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['catalog','compose','evaluate','example'])
    parser.add_argument('--request',help='compose keyword arguments as JSON')
    parser.add_argument('--config',help='resolved configuration JSON')
    parser.add_argument('--observations',help='explicit observations JSON')
    parser.add_argument('--time',type=float,default=0)
    parser.add_argument('--output',help='write JSON here instead of standard output')
    args=parser.parse_args()
    try:
        if args.action=='catalog':result=catalog()
        elif args.action=='compose':
            if not args.request:raise ContractError('--request required')
            result=compose(**read(args.request)).to_dict()
        else:
            if not args.config:raise ContractError('--config required')
            config=import_configuration(read(args.config))
            if args.action=='example':result=example(config)
            else:
                if not args.observations:raise ContractError('--observations required')
                result=evaluate(config,read(args.observations),time_s=args.time)
        text=json.dumps(result,indent=2,allow_nan=False)+'\n'
        if args.output:Path(args.output).write_text(text)
        else:print(text,end='')
    except (ContractError,TypeError,ValueError,KeyError,OSError) as exc:
        parser.exit(2,'Configuration rejected: '+str(exc)+'\n')


if __name__=='__main__':main()
