import marimo

__generated_with = '0.25.2'
app = marimo.App(width='medium', app_title='Substrate configuration builder')

@app.cell
def _():
    import marimo as mo
    import json
    import sys
    from pathlib import Path
    _root=Path(__file__).resolve().parent
    if str(_root) not in sys.path:
        sys.path.insert(0,str(_root))
    from Resources import catalog, compose, evaluate, example, WOUNDS, ContractError
    mo.md('''# Build a substrate-bound configuration

Select a substrate, compatible wounds, and an optional compute component. All
controls call the same registry used by agents. The observation editor starts
with an explicitly labeled teaching fixture. Replace it with your own data and
retain the units shown in the selected notebook.

A parallel compute assessment does not imply a physical coupling. The receipt
states which relationship is implemented.''')
    return mo, json, catalog, compose, evaluate, example, WOUNDS, ContractError

@app.cell
def _(mo, catalog):
    substrate=mo.ui.dropdown({p['title']:p['id'] for p in catalog()},
                            value='Jackal stopping and traction',label='Substrate')
    substrate
    return (substrate,)

@app.cell
def _(mo, substrate, catalog, WOUNDS):
    selected=next(p for p in catalog() if p['id']==substrate.value)
    _choices=[k for k,w in WOUNDS.items() if selected['strategy'] in w['strategies']]
    wound_selection=mo.ui.multiselect(_choices,value=[],label='Compatible substrate wounds')
    _boards={'None':'none'}
    if selected['strategy']!='compute':
        _boards.update({p['title']:p['id'] for p in catalog() if p['strategy']=='compute'})
    compute_selection=mo.ui.dropdown(_boards,value='None',label='Compute component')
    severity=mo.ui.slider(0,1,step=.05,value=.25,label='Selected wound severity')
    mo.vstack([wound_selection,compute_selection,severity])
    return selected, wound_selection, compute_selection, severity

@app.cell
def _(mo, json, selected, compute_selection, compose, example):
    _compute=None if compute_selection.value=='none' else compute_selection.value
    _config=compose(selected['id'],compute=_compute)
    observations=mo.ui.text_area(value=json.dumps(example(_config),indent=2),
                                 label='Explicit observation fixture [native units]',rows=14,debounce=300)
    overrides=mo.ui.text_area(value='{}',label='Parameter overrides [native units; JSON]',rows=4,debounce=300)
    mo.vstack([observations,overrides])
    return observations, overrides

@app.cell
def _(mo, json, selected, compute_selection, wound_selection, severity,
      observations, overrides, compose, evaluate, ContractError):
    try:
        _compute=None if compute_selection.value=='none' else compute_selection.value
        config=compose(selected['id'],compute=_compute,
                       wounds=[{'id':w,'severity':severity.value} for w in wound_selection.value],
                       overrides=json.loads(overrides.value))
        receipt=evaluate(config,json.loads(observations.value))
        panel=mo.vstack([mo.md('**Assessment:** '+receipt['disposition']),
            mo.accordion({'Resolved configuration':mo.json(config.to_dict()),
                          'Full evaluation receipt':mo.json(receipt)}),
            mo.download(data=json.dumps(config.to_dict(),indent=2).encode(),
                        filename='substrate_configuration.json',label='Download configuration'),
            mo.download(data=json.dumps(receipt,indent=2).encode(),
                        filename='substrate_receipt.json',label='Download receipt')])
    except (ContractError,ValueError,TypeError,KeyError) as error:
        config=None;receipt=None
        panel=mo.callout('Configuration rejected: '+str(error),kind='warn')
    panel
    return config, receipt

if __name__=='__main__':
    app.run()
