# One configuration, visible couplings

The worked system is a Jackal stopping model with a Pi compute component. Two disturbances act at different places: traction loss reduces braking deceleration; thermal rise increases a **scenario-defined** compute latency. The coupling is explicit:

$$d=|v|(t_{plant}+t_{compute})+\frac{v^2}{2a\mu}.$$

The plant latency excludes the selected compute stage. That convention prevents double counting. The temperature-to-delay coefficient is synthetic until measured on the chosen board, power mode, cooling setup, and workload.

The compute component starts at 79°C in this experiment. Its policy already selects CONTINGENCY. A thermal wound changes the observed scenario temperature and the estimated stage delay. Traction loss begins at 10 seconds, reaches its selected severity at 20 seconds, and recovers after 60 seconds. The thermal effect persists. Predict why the stopping distance does not return to its initial value after traction recovers.

```python
from Resources import compose, example, evaluate

config = compose(
    "ugv.clearpath_jackal.v3",
    compute="controller.raspberry_pi5_8gb.v1",
    wounds=[
        {"id": "traction_loss", "severity": 0.5},
        {"id": "thermal_rise", "target": "compute", "severity": 0.5},
    ],
)
observations = example(config)  # explicit teaching fixture
receipt = evaluate(config, observations, time_s=20)
```

For other physical substrates, a compute component can be assessed in parallel. Its metrics and policy state appear in the receipt, but no unvalidated physical coupling is invented. The receipt identifies `parallel_assessment` versus `ground_stopping_latency`.

To export a configuration, serialize `config.to_dict()` with `json.dumps(..., allow_nan=False)`. To import it, use `import_configuration(document)`. Import re-resolves the request against the current catalog and rejects altered or stale definitions. Catalog version, catalog hash, executable-implementation hash, and source-index hash accompany each result; a version name alone cannot establish identity.
