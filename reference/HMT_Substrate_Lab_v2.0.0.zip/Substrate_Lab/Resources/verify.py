"""Reproducible gates and compact SQLite continuity ledgers."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import ast
import json
import sqlite3
from .registry import ROOT
from .check_contracts import check_catalog, check_wounds, check_coupling
from .check_physics import check_physics, check_remaining
from .check_dimensions import check_dimensions, check_component_matrix
from .check_bounds import check_bounds
from .check_handoff import check_handoff

ROWS=[]


def check(gate,subject,reason,status='PASS'):
    ROWS.append(dict(gate=gate,subject=subject,status=status,reason=reason))


def structure():
    for path in ROOT.parent.rglob('*.py'):
        if '__pycache__' in str(path):continue
        text=path.read_text();tree=ast.parse(text)
        assert len(text.splitlines())<180,(str(path),'module',len(text.splitlines()))
        for n in ast.walk(tree):
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
                assert n.end_lineno-n.lineno+1<60,(str(path),n.name,n.end_lineno-n.lineno+1)
    check('G-STRUCTURE-030','active Python','all modules <180 lines; functions <60 lines')


def save():
    raw=json.dumps(ROWS,indent=2);(ROOT/'evidence/verification.json').write_text(raw)
    stamp=datetime.now(timezone.utc).isoformat();digest=sha256(raw.encode()).hexdigest()
    snapshot='gates_'+digest[:16]+'.json'
    (ROOT/'evidence'/snapshot).write_text(raw)
    db=sqlite3.connect(ROOT/'evidence/continuity.sqlite')
    db.execute('CREATE TABLE IF NOT EXISTS "Cumulative Gate Ledger" (timestamp, task, gate_id, requirement, status, evidence_ref, evidence_hash_reason)')
    for r in ROWS:
        db.execute('INSERT INTO "Cumulative Gate Ledger" VALUES (?,?,?,?,?,?,?)',
                   (stamp,'substrate-v2',r['gate'],r['subject'],r['status'],snapshot,digest+'; '+r['reason']))
    db.execute('CREATE TABLE IF NOT EXISTS "Reverse RCA Ledger" (timestamp, incident_id, checkpoint, observed_state, causal_evidence, validation_test, disposition)')
    db.commit();db.close()
    print(json.dumps({'checks':len(ROWS),'passed':sum(r['status']=='PASS' for r in ROWS),'open_reference':sum(r['status']!='PASS' for r in ROWS)},indent=2))


def main():
    ROWS.clear()
    check_catalog(check);check_wounds(check);check_coupling(check)
    check_physics(check);check_remaining(check)
    check_dimensions(check);check_component_matrix(check);check_bounds(check);check_handoff(check);structure()
    import sys
    if '--references' in sys.argv:
        from .check_legacy import check_reference,check_declared_formulas
        check_reference(check);check_declared_formulas(check)
        from .check_recovered import check_recovered,check_recovered_laws
        check_recovered(check);check_recovered_laws(check)
    save()


if __name__=='__main__':main()
