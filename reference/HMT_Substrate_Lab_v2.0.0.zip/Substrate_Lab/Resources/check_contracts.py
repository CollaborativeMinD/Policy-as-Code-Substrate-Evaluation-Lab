"""Catalog, input, serialization, and composition regression gates."""
from copy import deepcopy
import itertools
from . import catalog, compose, example, evaluate, import_configuration, ContractError, WOUNDS
from .contracts import ResolvedConfiguration, canonical


def rejected(call):
    try:
        call()
    except (ContractError,TypeError,KeyError):
        return
    raise AssertionError('invalid request was accepted')


def check_catalog(check):
    profiles = catalog(); ids = [p['id'] for p in profiles]
    assert len(ids)==len(set(ids))==20
    for p in profiles:
        c = compose(p['id']); x = example(c); result = evaluate(c,x)
        assert set(result['metrics'])==set(p['outputs'])
        assert import_configuration(c.to_dict()).digest==c.digest
        for alias in p['aliases']:
            assert compose(alias).digest==c.digest
        check('G-CATALOG-001',p['id'],'all declared outputs, aliases, and round-trip')
        for key in x:
            broken = deepcopy(x); broken.pop(key)
            rejected(lambda: evaluate(c,broken))
        for field in p['inputs']:
            key = field['name']
            for value in [True,'1',float('nan'),float('inf'),None]:
                broken = deepcopy(x); broken[key]=value
                rejected(lambda: evaluate(c,broken))
            broken = deepcopy(x); broken[key]={'value':x[key],'unit':'WRONG'}
            rejected(lambda: evaluate(c,broken))
            check('G-INPUT-002',p['id']+'.'+key,'missing, type, finite, and unit gates')
        rejected(lambda: compose(p['id'],overrides={'unknown':0}))
        tampered = c.to_dict(); tampered['parameters'][p['parameters'][0]['name']]=123
        rejected(lambda: evaluate(ResolvedConfiguration(canonical(tampered)),x))
        check('G-IMMUTABLE-003',p['id'],'tampered resolved configuration rejected')


def check_wounds(check):
    pairs = 0
    for p,w in itertools.product(catalog(),WOUNDS):
        request = [{'id':w,'severity':.5}]
        compatible = p['strategy'] in WOUNDS[w]['strategies']
        if compatible:
            c = compose(p['id'],wounds=request)
            evaluate(c,example(c));pairs+=1
            rejected(lambda: compose(p['id'],wounds=request+request))
            for s in [0, .25, .5, .75, 1]:
                c = compose(p['id'],wounds=[{'id':w,'severity':s}])
                evaluate(c,example(c))
        else:
            rejected(lambda: compose(p['id'],wounds=request))
        check('G-WOUND-004',p['id']+'/'+w,'accepted' if compatible else 'incompatible rejected')
    assert pairs>0
    base = 'ugv.clearpath_jackal.v3'
    a={'id':'traction_loss','severity':.3}; b={'id':'compute_delay','severity':.4}
    assert compose(base,wounds=[a,b]).digest==compose(base,wounds=[b,a]).digest
    rejected(lambda: compose(base,wounds=[{'id':'traction_loss','severity':1.1}]))
    rejected(lambda: compose(base,wounds=[{'id':'traction_loss','severity':.1,'rise_s':10,'end_s':5}]))
    check('G-COMPOSE-005',base,'commutative order canonicalized; invalid timeline rejected')


def check_coupling(check):
    sid='ugv.clearpath_jackal.v3'; board='controller.raspberry_pi5_8gb.v1'
    base=compose(sid,compute=board); x=example(base); x['compute']['temperature_c']=79
    nominal=evaluate(base,x)
    wounded=compose(sid,compute=board,wounds=[{'id':'thermal_rise','target':'compute','severity':.5},{'id':'traction_loss','severity':.5}])
    result=evaluate(wounded,x)
    p=result['effective_parameters']; v=x['speed_m_s']; a=p['brake_decel_m_s2']*.5
    expected=v*(.1+.01+.01*19)+v*v/(2*a)
    assert abs(result['metrics']['stopping_distance_m']-expected)<1e-12
    assert result['metrics']['stopping_distance_m']>nominal['metrics']['stopping_distance_m']
    assert result['compute']['policy_state']=='TERMINAL_POLICY'
    rejected(lambda: evaluate(base,{k:v for k,v in x.items() if k!='compute'}))
    check('G-COUPLING-006','Jackal + Pi','thermal -> latency -> stopping; traction affects braking only')
