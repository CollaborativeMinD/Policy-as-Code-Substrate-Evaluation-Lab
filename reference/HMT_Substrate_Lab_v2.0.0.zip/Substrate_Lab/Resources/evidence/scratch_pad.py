"""Pre-build tracers. Run with Python; no platform or notebook dependencies."""
import json
import math
from pathlib import Path


def finite(value):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError('a real number is required')
    if not math.isfinite(value):
        raise ValueError('a finite number is required')
    return float(value)


def thermal_state(temp):
    t = finite(temp)
    return 'CONTINGENCY' if t >= 78 else 'ALTERNATE' if t >= 70 else 'NOMINAL'


def stopping_distance(v, a, latency, traction, compute_fraction):
    if not (0 < traction <= 1 and 0 < compute_fraction <= 1):
        raise ValueError('positive retained capability is required')
    return v * latency / compute_fraction + v * v / (2 * a * traction)


def replay_torque(payload, joint):
    limits = payload['joint_dynamics']['torque_limits']
    if len(limits) != 7 or not all(finite(x) > 0 for x in limits):
        raise ValueError('seven positive torque limits required')
    return limits[joint]


def run():
    records = []
    def check(name, actual, expected):
        assert actual == expected, (name, actual, expected)
        records.append({'gate': name, 'actual': actual, 'expected': expected})
    check('T-001 threshold decision', thermal_state(79), 'CONTINGENCY')
    for value in [True, '79', float('nan'), float('inf')]:
        try:
            thermal_state(value)
        except ValueError:
            records.append({'gate': 'T-002 invalid observation', 'rejected': repr(value)})
        else:
            raise AssertionError(value)
    base = stopping_distance(2, 1, .1, 1, 1)
    wounded = stopping_distance(2, 1, .1, .5, .5)
    check('T-003 physical coupling', wounded, 2 * base)
    payload = {'joint_dynamics': {'torque_limits': [60, 87, 87, 87, 12, 12, 12]}}
    check('T-004 replay data reaches law', replay_torque(payload, 0), 60)
    return records


if __name__ == '__main__':
    out = Path(__file__).with_name('tracer_results.json')
    out.write_text(json.dumps(run(), indent=2))
    print(out.read_text())
