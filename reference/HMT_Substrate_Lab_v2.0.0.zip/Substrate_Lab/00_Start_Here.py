import marimo

__generated_with = "0.25.2"
app = marimo.App(width="medium", app_title='Substrate Lab · Start here')

@app.cell
def _():
    import marimo as mo
    from pathlib import Path
    import json
    root = Path(__file__).resolve().parent
    mo.md((root/"Resources/orientation.md").read_text())
    return mo, root, json

@app.cell
def _(mo, root, json):
    _cards=json.loads((root/"Resources/lessons.json").read_text())
    mo.ui.table([{k:c[k] for k in ["number","title","id","strategy"]} for c in _cards],selection=None,page_size=20)
    return

if __name__ == "__main__":
    app.run()
